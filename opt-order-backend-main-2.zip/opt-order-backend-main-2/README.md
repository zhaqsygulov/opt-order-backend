# FastAPI VendorAPI Adapter

API для интеграции с VendorAPI МоегоСклада.